from PIL import Image
  
def most_common_used_color(img):
    width, height = img.size
  
    r_total = 0
    g_total = 0
    b_total = 0
    count = 0
  
    
    for x in range(0, width):
        for y in range(0, height):
            r, g, b = img.getpixel((x, y))
            r_total += r
            g_total += g
            b_total += b
            count += 1
  
    return (r_total/count, g_total/count, b_total/count)

img = Image.open(r'C:\\Users\\ANKITA\\Downloads\\baloon.jpg')
img = img.convert('RGB')
common_color = most_common_used_color(img)
  
print(common_color)
